//
//  AdoComponent.h
//  AdoComponent
//
//  Created by Gerard Amortegui on 21/12/20.
//

#import <Foundation/Foundation.h>

//! Project version number for AdoComponent.
FOUNDATION_EXPORT double AdoComponentVersionNumber;

//! Project version string for AdoComponent.
FOUNDATION_EXPORT const unsigned char AdoComponentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdoComponent/PublicHeader.h>


